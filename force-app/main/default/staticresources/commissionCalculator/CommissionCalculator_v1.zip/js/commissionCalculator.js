(function($, document, window) {

  window.CommissionCalc = {

  /*
    @oppId = the Id of the Opportunity we need to calculate the commission on
    @templates = object - name, handlebars compiled templates
       {'indicator', Handlebars.compile( $(ele).html() ) }
       make sure to compile templates before passing in
  */

  init: function(oppId, templates)
  {
    this.oppId = oppId;
    this.tempItemData = {};
    this.Items = {};
    this.recordId,
    this.$container = $('#content');
    this.$recreateRecordBtn = $('#recreateRecord');
    this.templates = templates;

    var self = this;

    self.templates.emptyRow = Handlebars.compile(
      "<tr class='emptyRow'><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>"
       + "<a href='#' class='fd_button tiny invert success addItem' data-percentage='{{{this}}}'>"
       + "<i class='fa fa-plus'></i>"
       + "<i class='fa fa-circle-o-notch fa-spin'></i>"
       + "</a></td></tr>");

    Handlebars.registerHelper('tableRow', function( item ){
      return new Handlebars.SafeString( self.templates.row(item) );
    });

    self.$container.html( self.templates.indicator('Retrieving Commission Record .....'));
    $.when( self.Model.fetchRecord.call(self) ).done( function(result) {
      console.log('fetching record complete');
      console.log(result)
      if( result === null || result.items === null || result.items.length === 0 )
      {
        $.when( self.Model.createRecord.call(self) )
        .done( function(data) {
          self.createItemObject.call(self, data.items);
          self.View.displayTable.call(self, data);
        })
        .fail(function(message){
          self.View.setFailedLoadingMessage(message);
        });
      }
      else
      {
        console.log(' I received some stuff ');
        self.groupItems.call(self, result.items);
        self.createItemObject.call(self, result.items);
        //self.View.displayTable.call(self, result);
      }
    })
    .fail( function(message) {
       self.View.setFailedLoadingMessage(message);
    }) ;

  }, // /init

  groupItems: function(items)
  {
    console.log(items);
    var self = this,
    result = {};
    result.first = [];
    result.second = [];
    result.third = [];

    $.each(items, function(idx, item) {
      switch(item.CommissionRate)
      {
        case 1.75:
          result.first.push(item);
          break;
        case 10:
          result.second.push(item);
          break;
        default:
          result.third.push(item);
      }
    });
    console.log(result);
    self.View.displayTable.call(self, result);
  },

  /*

  createItemObject:
    @items = array of items returned from AJAX call tp apex controller
    sets Items property on CommissionCalc object {item.Id, item}
    makes it easy to retrieve item information from Items objects

  */
  createItemObject: function(items)
  {
    var self = this;
    $.each( items, function( idx, item) {
      self.Items[item.Id] = item;
    });
  }, // /createItemObject

  getItemsFromObject: function()
  {
    var self = this,
    data = [];
    $.each( self.Items, function(id, item) {
      data.push(item);
    });
    return {items: data};
  },// /getItemsFromObject

  recreateRecord: function()
  {
    var self = this;
    $.when( self.Model.deleteRecord.call(self) )
    .done( function() {
      $.when( self.Model.createRecord.call(self) ).done( function(data) {
        self.createItemObject.call(self, data.items);
        self.View.displayTable.call(self, data);
      });
    })
    .fail( function(error) {
      alert(error);
      var data = self.getItemsFromObject.call(self);
      self.View.displayTable.call( self, data );
    });
  }, // /recreateRecord


  Model: {

    fetchRecord: function()
    {
      var self = this,
        wrapper,
        dfd = new $.Deferred();
      CommissionCalculatorController_v1.fetchRecord( self.oppId, function(result, event) {
        if( event.status )
        {
          if(result === null)
          {
            dfd.resolve(null);
          }
          else
          {
            $.each(result, function( recordId, items){
              wrapper = {items: items};
              self.recordId = recordId;
            });
            dfd.resolve(wrapper);
          }
        }
        else
        {
          dfd.reject(event.message);
        }
      });
      return dfd.promise();
    },// /fetchRecord

    createRecord: function()
    {
      var self = this,
        wrapper,
        dfd = new $.Deferred();

      self.View.setLoadingMessage('Creating Record ....');
      CommissionCalculatorController_v1.createRecord(self.oppId, function(result, event) {
        if( event.status )
        {
          $.each(result, function( recordId, items){
            wrapper = {items: items};
            self.recordId = recordId;
          });
          dfd.resolve(wrapper);
        }
        else
        {
          dfd.reject(event.message);
        }
      });
     return dfd.promise();
    },// /createRecord

    deleteRecord: function()
    {
      var self = this,
        dfd = new $.Deferred();

      self.$container.html( self.templates.indicator('Deleting Record ...') );
      CommissionCalculatorController_v1.deleteRecord( self.recordId , function( result, event ) {
        if( event.status )
        {
          dfd.resolve();
        }
        else
        {
          dfd.reject(event.message);
        }
      });
      return dfd.promise();
    }, // / deleteRecord

    updateItem: function(data)
    {
      var dfd = new $.Deferred(),
        message;
      CommissionCalculatorController_v1.updateItem( JSON.stringify(data), function(result, event) {
        if( event.status )
        {
          dfd.resolve(result);
        }
        else
        {
          message = event.message.indexOf('Logged in?') !== -1 ?
            ' Your session has expired.  Please refresh your browser and log in.' :
            event.message;
          dfd.reject(message);
        }
      });
      return dfd.promise();
    }

  },// /Model

  View: {

    setLoadingMessage: function(message)
    {
      $('#indicator .indicator_message').html(message);
    },

    setFailedLoadingMessage: function(message)
    {
      $('#indicator').addClass('error').find('.indicator_message').html(message);
    },

    displayTable: function(data)
    {
      var self = this,
        $tbody;

      self.$container.html( self.templates.table() );
      $tbody = $('table.commissionTable tbody');
      $tbody.append( self.templates.rows( {items: data.first} ) )
      .append( self.templates.emptyRow('1.75') )
      .append( self.templates.rows({ items: data.second} ) )
      .append( self.templates.emptyRow('10') )
      .append( self.templates.rows( {items: data.third} ) )
      .append( self.templates.emptyRow('') );
      self.$recreateRecordBtn.show()
      .on('click', function(e) {
        e.preventDefault();
        self.recreateRecord.call(self);
        $(this).off('click');
      });
      self.View.Table.init.call(self);
    },

    Table: {

      init: function()
      {
        var self = this;
        self.View.Table.$table = $('.commissionTable');
        self.View.Table.sumColumns.call(self);
        self.View.Table.initClickEvents.call(self);

      },// /init

      sumColumns: function()
      {
       var $table = this.View.Table.$table,
        $bodyRows = $table.find('tbody tr'),
        $footerRow = $table.find('tfoot tr:first'),
        totals = {},
        $cellsWithTotals = $table.find('thead td.hasTotal');

        $.each($cellsWithTotals, function(inx,ele) {
          totals[ $(ele).index() ] = 0;
        });

        $.each($bodyRows, function(idx, ele){
          var $row = $(ele);
          $.each( totals, function(idx, value){
            var amount = Number( $row.find('td').eq(idx).html().replace(/[^0-9\-.]+/g,"") );
            totals[idx] += amount;
          });
        });

        $.each(totals, function(idx, value){
          $footerRow.find('td').eq(idx).html('$ ' + value.toFixed(2) );
        });
      },// /sumColumns

      initClickEvents: function()
      {
        var self = this,
          $table = self.View.Table.$table;

        $table.on('click', 'a.editItem', function(e) {
          e.preventDefault();
          var $this = $(this),
            iId = $this.data('id'),
            $row = $this.closest('tr');
          $this.addClass('busy');
          $row.replaceWith( self.templates.edit_row( self.Items[iId]) );
          self.View.Table.initInputs.call(self, iId);
        })
        .on('click', 'a.cancelEdit', function(e){
          e.preventDefault();
          var $this = $(this),
            $row = $this.closest('tr'),
            itemId = $this.data('id');

          $row.replaceWith( self.templates.row(self.Items[itemId]) );
        })
        .on('click', 'a.updateItem', function(e){
          e.preventDefault();
          var $this = $(this),
            $row = $this.closest('tr'),
            data = {},
            itemId = $this.data('id');

          data['Id'] = itemId;
          $this.addClass('busy');
          $row.find('input').each( function( idx, ele) {
            data[ $(ele).data('field-name') ] = $(ele).val();
          });
          $.when( self.Model.updateItem.call(self, data) )

          .done( function(result) {
            $row.replaceWith( self.templates.row( result ) );
            self.Items[itemId] = result;
            self.View.Table.sumColumns.call(self);
          })

          .fail( function(message) {
            alert(message);
            $row.replaceWith( self.templates.row( self.Items[itemId] ) );
          })
        })
        .on('click', 'a.addItem', function(e) {
          e.preventDefault();
          var $this = $(this);

          console.log($this.data('percentage') );
        });
      },

      initInputs: function(itemId)
      {
        var self = this,
          $inputs = $('#' + itemId).find('input'),
          inputsMap = {},
          itemTotalPrice = self.Items[itemId].TotalPrice,
          isNumberKey = function(evt)
          {
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode != 46 && charCode > 31
              && (charCode < 48 || charCode > 57) //keyboardnumbers
               && charCode != 189
               && charCode != 109
               && charCode != 37 //left key
               && charCode != 39 //right key
               && charCode != 190 // period
               && charCode != 110 //numberpad decimal
               && (charCode > 105 || charCode < 96) ) //numberpad numbers
               return false;

            return true;
          },
          handleAmountChange = function($input)
          {
            var v = $input.val(),
              calcVal,
              price = self.Items[itemId].TotalPrice === 0 ?
                ( self.Items[itemId].RetailPrice * self.Items[itemId].Quantity ) :
                self.Items[itemId].TotalPrice,
              typ;
              console.log('handling amount change')
            if( $input.data('field-type') === 'percentage' )
            {
              typ = 'currency';
              calcVal = ( price * ( v / 100) );
            }
            if( $input.data('field-type') === 'currency' )
            {
              typ = 'percentage';
              calcVal = (v / price) * 100
            }
            inputsMap[typ].val(calcVal.toFixed(2));
          },
          handleCurrency = function($input)
          {
            var v = $input.val();
          }

        $inputs.each(function(idx,ele) {
          var $this = $(ele);
          // if( itemTotalPrice === 0 && $this.data('field-type') === 'percentage')
          // {
          //   $this.attr('disabled', 'disabled');
          // }
          // else
          // {
            inputsMap[ $this.data('field-type') ] = $this;
          // }
        })
        .on({
          keydown: function(e) {
            if( !isNumberKey(e) )
            {
              e.preventDefault();
            }
          },
          keyup: function(e) {
            // if( !parseFloat(itemTotalPrice) == 0 )
            // {
              handleAmountChange( $(this) );
            // }
          }
        });

      }

    }// /Table

  }// /View

}// CommissionCalc

})(jQuery, document, window, undefined);
